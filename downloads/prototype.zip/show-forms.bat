@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run-final.ps1" -Replay %*
if errorlevel 1 pause
