@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0prepare-qwen.ps1" %*
if errorlevel 1 (
  echo Preparation failed. See the message above.
  pause
  exit /b 1
)
