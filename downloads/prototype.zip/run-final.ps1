param([switch]$Offline,[switch]$NoBrowser,[switch]$Replay)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$basePort = if ($Replay) {8270} else {8260}
$ui = "http://127.0.0.1:$basePort"
foreach ($port in @($basePort,($basePort+1))) {
    $probe = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,$port)
    try {$probe.Start()} catch {throw "Port $port is in use. Check the running demo."} finally {$probe.Stop()}
}
$env:WEBHOOK_SECRET = [guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N')
$env:SEED_SYNTHETIC='false'
$env:DEMO_MODE='false'
$env:PUBLIC_URL=$ui
$env:ADDR="127.0.0.1:$basePort"
$env:FORMS_ADDR="127.0.0.1:$($basePort+1)"
$env:PULSE_ENDPOINT=$ui
$env:STATE_FILE='state/state.json'
$env:DATA_DIR='data'
$env:SURVEY_FILE='data/survey.json'
$env:WEB_DIR='web'
$modelPath=$env:PULSE_MODEL_DIR
if (!$modelPath -and (Test-Path 'model/runtime/llama-server.exe')) {$modelPath=(Resolve-Path 'model').Path}
if (!$modelPath) {
    $sibling = Get-ChildItem -LiteralPath '..' -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'model/runtime/llama-server.exe') } | Select-Object -First 1
    if ($sibling) {$modelPath=Join-Path $sibling.FullName 'model'}
}
$formsDir = $PSScriptRoot
if ($Replay) {
    $formsDir=Join-Path $PSScriptRoot ('rehearsals\'+[guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path (Join-Path $formsDir 'data') -Force | Out-Null
    Copy-Item -LiteralPath 'data/survey.json' -Destination (Join-Path $formsDir 'data/survey.json')
    $env:STATE_FILE=Join-Path $formsDir 'state.json'
    Copy-Item -LiteralPath 'data/replay-before-m6.json' -Destination $env:STATE_FILE
}
$forms = Start-Process (Join-Path $PSScriptRoot 'forms-service.exe') -WindowStyle Hidden -WorkingDirectory $formsDir -PassThru
$server=$null
try {
    Write-Host "HR dashboard  $ui"
    Write-Host "Forms         http://$($env:FORMS_ADDR)/"
    $sharedModel = $null
    if ($Replay -and !$Offline) {
        try {$sharedModel=(Invoke-RestMethod 'http://127.0.0.1:8262/v1/models' -TimeoutSec 2).data[0].id} catch {}
    }
    if (!$Offline -and $modelPath -and !$sharedModel) {
        & '.\start-qwen.ps1' -ModelDir $modelPath -Port $basePort -ModelPort ($basePort+2) -NoBrowser:$NoBrowser
    } else {
        if ($sharedModel) {
            $env:LLM_MODEL=$sharedModel
            $env:LLM_MOCK='false'
            $env:LLM_BASE_URL='http://127.0.0.1:8262/v1'
            $env:LLM_API_KEY='local-inference'
        } else {
            $env:LLM_MOCK='true'
            Write-Host 'Text analysis uses the offline dictionary.'
        }
        $server=Start-Process '.\pulse.exe' -WindowStyle Hidden -WorkingDirectory $PSScriptRoot -PassThru
        $ready=$false
        for ($i=0;$i -lt 60;$i++) {
            if ($server.HasExited -or $forms.HasExited){throw 'A service failed to start.'}
            try {if ((Invoke-RestMethod "$ui/health" -TimeoutSec 1).status -eq 'ok') {$ready=$true;break}} catch {}
            Start-Sleep -Milliseconds 250
        }
        if (!$ready){throw 'Dashboard startup timed out.'}
        if (!$NoBrowser){Start-Process $ui}
        $server.WaitForExit()
    }
} finally {
    foreach ($process in @($forms,$server)) {
        if ($process -and !$process.HasExited){$process.Kill();$process.WaitForExit()}
    }
}
