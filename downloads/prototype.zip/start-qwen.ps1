param(
    [string]$ModelDir = $env:PULSE_MODEL_DIR,
    [ValidatePattern('^(Vulkan|CUDA)[0-9]+$')][string]$Device,
    [ValidateRange(1,65535)][int]$Port = 8080,
    [ValidateRange(1,65535)][int]$ModelPort = 8081,
    [switch]$NoBrowser,
    [switch]$CheckOnly
)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (!$ModelDir) { $ModelDir = Join-Path $PSScriptRoot 'model' }
if ($Port -eq $ModelPort) { throw 'Choose different ports for Pulse and Qwen.' }

$engine = Join-Path $ModelDir 'runtime\llama-server.exe'
$weightName = 'qwen.gguf'
$modelName = 'Qwen2.5-3B-Instruct-Q4_K_M'
$shard = 'qwen2.5-7b-instruct-q4_k_m-00001-of-00002.gguf'
if (Test-Path -LiteralPath (Join-Path $ModelDir $shard) -PathType Leaf) {
    $weightName = $shard
    $modelName = 'Qwen2.5-7B-Instruct-Q4_K_M'
    if (!(Test-Path -LiteralPath (Join-Path $ModelDir $shard.Replace('00001','00002')) -PathType Leaf)) {
        throw 'Missing second Qwen 7B weights file.'
    }
}
$weight = Join-Path $ModelDir $weightName
$pulse = Join-Path $PSScriptRoot 'pulse.exe'
foreach ($file in @($engine, $weight, $pulse, 'web\index.html', 'data\survey.json')) {
    if (!(Test-Path -LiteralPath $file -PathType Leaf)) {
        throw "Missing file: $file. See the Windows instructions included with the demo."
    }
}
$ModelDir = (Resolve-Path -LiteralPath $ModelDir).Path
foreach ($p in @($Port,$ModelPort)) {
    $probe = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $p)
    try { $probe.Start() } catch { throw "Port $p unavailable. Stop the existing server or choose another port." }
    finally { $probe.Stop() }
}

# Windows closes the job handle when this launcher exits, including a closed console.
# Each job contains only the two processes started by this invocation.
Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
public sealed class PulseJob : IDisposable {
    [StructLayout(LayoutKind.Sequential)] struct Limits {
        public long ProcessTime, JobTime; public uint Flags;
        public UIntPtr MinWorkingSet, MaxWorkingSet; public uint MaxProcesses;
        public UIntPtr Affinity; public uint Priority, Scheduling;
        public ulong ReadOps, WriteOps, OtherOps, ReadBytes, WriteBytes, OtherBytes;
        public UIntPtr ProcessMemory, JobMemory, PeakProcess, PeakJob;
    }
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern SafeFileHandle CreateJobObject(IntPtr attributes, string name);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool SetInformationJobObject(SafeFileHandle job, int type, ref Limits limits, int length);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool AssignProcessToJobObject(SafeFileHandle job, IntPtr process);
    readonly SafeFileHandle handle = CreateJobObject(IntPtr.Zero, null);
    public PulseJob() {
        var limits = new Limits { Flags = 0x2000 }; // JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if (handle.IsInvalid || !SetInformationJobObject(handle, 9, ref limits, Marshal.SizeOf(typeof(Limits))))
            throw new Win32Exception(Marshal.GetLastWin32Error());
    }
    public void Add(Process process) {
        if (!AssignProcessToJobObject(handle, process.Handle)) throw new Win32Exception(Marshal.GetLastWin32Error());
    }
    public void Dispose() { handle.Dispose(); }
}
'@
function Wait-ServiceReady($Process, $Url) {
    $deadline = [datetime]::UtcNow.AddSeconds(120)
    while ([datetime]::UtcNow -lt $deadline) {
        if ($Process.HasExited) { throw "$($Process.ProcessName) exited before readiness. Check files and ports." }
        try {
            if ((Invoke-RestMethod ($Url + '/health') -TimeoutSec 2).status -eq 'ok') { return }
        } catch {}
        Start-Sleep -Milliseconds 250
    }
    throw "Timed out waiting for $Url/health."
}

$ui = "http://127.0.0.1:$Port"
$llm = "http://127.0.0.1:$ModelPort"
$job = [PulseJob]::new()
$runtime = $null
$server = $null
try {
    Write-Host 'Loading portable Qwen on this computer...'
    $modelArgs = @('-m',$weightName,'--alias',$modelName,'--host','127.0.0.1','--port',$ModelPort,
        '-c',2048,'-t',4,'-np',1)
    if ($Device) { $modelArgs += @('-ngl',99,'--device',$Device) }
    elseif ($modelName -like '*-7B-*') { $modelArgs += @('-ngl','auto') }
    else { $modelArgs += @('-ngl',0) }
    $runtime = Start-Process -FilePath $engine -WorkingDirectory $ModelDir -WindowStyle Hidden -PassThru -ArgumentList $modelArgs
    $job.Add($runtime)
    Wait-ServiceReady $runtime $llm
    $env:ADDR = "127.0.0.1:$Port"
    $env:PUBLIC_URL = $ui
    $env:CORS_ORIGINS = $ui
    $env:LLM_BASE_URL = "$llm/v1"
    $env:LLM_MODEL = $modelName
    $env:LLM_API_KEY = 'local-inference'
    $env:LLM_MOCK = 'false'
    $env:DEMO_MODE = 'false'
    $env:WEB_DIR = 'web'
    if (!$env:STATE_FILE) { $env:STATE_FILE = 'state\state.json' }
    $server = Start-Process -FilePath $pulse -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -PassThru
    $job.Add($server)
    Wait-ServiceReady $server $ui
    $headers = @{}
    if ($env:HR_TOKEN) { $headers.Authorization = "Bearer $($env:HR_TOKEN)" }
    $sources = Invoke-RestMethod "$ui/api/v1/sources" -Headers $headers -TimeoutSec 10
    if ($sources.analyzer.mode -ne 'llm' -or $sources.analyzer.model -ne $modelName) {
        throw 'Pulse is ready but its model configuration does not match the local Qwen.'
    }
    if ((Invoke-WebRequest $ui -UseBasicParsing -TimeoutSec 10).StatusCode -ne 200) { throw 'The dashboard did not open.' }
    Write-Host "Ready: $ui  |  $modelName"
    if (!$CheckOnly) {
        if (!$NoBrowser) { Start-Process $ui }
        Write-Host 'Keep this window open. Press Ctrl+C or close it to stop both services.'
        $reportedModelExit = $false
        while (!$server.WaitForExit(500)) {
            if ($runtime.HasExited -and !$reportedModelExit) {
                Write-Warning 'Qwen stopped. Pulse remains available and uses the built-in dictionary for new comments.'
                $reportedModelExit = $true
            }
        }
        if ($server.ExitCode -ne 0) { throw "Pulse exited with status $($server.ExitCode)." }
    }
} finally {
    $job.Dispose()
    foreach ($child in @($runtime,$server)) {
        if ($child) {
            if (!$child.WaitForExit(1500)) { $child.Kill() }
            $child.WaitForExit()
            $child.Dispose()
        }
    }
}
