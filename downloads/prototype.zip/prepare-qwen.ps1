param(
    [ValidateSet('7B','3B')][string]$Profile = '7B',
    [string]$ModelDir = $env:PULSE_MODEL_DIR,
    [string]$CacheDir
)
$ErrorActionPreference = 'Stop'
if (!$ModelDir) { $ModelDir = Join-Path $PSScriptRoot 'model' }
$dest = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($ModelDir)
if ($CacheDir) { $CacheDir = (Resolve-Path -LiteralPath $CacheDir).Path }
$engineBase = 'https://github.com/ggml-org/llama.cpp/releases/download/b12613/'
if ($Profile -eq '7B') {
    $modelBase = 'https://huggingface.co/Qwen/Qwen2.5-7B-Instruct-GGUF/resolve/bb5d59e06d9551d752d08b292a50eb208b07ab1f/'
    $weights = @(
        @{ Name='qwen2.5-7b-instruct-q4_k_m-00001-of-00002.gguf'; Bytes=3993201344; SHA='dfce12e3862a5283ccfb88221b48480e58745165de856439950d0f22590580db' }
        @{ Name='qwen2.5-7b-instruct-q4_k_m-00002-of-00002.gguf'; Bytes=689872288; SHA='539cf93f78e887edea1c04e2d7d8cdaca9d01dae9c9025bcb8accbe29df3d72a' }
    )
    $engine = @{ Name='llama-b12613-bin-win-vulkan-x64.zip'; Bytes=38845965; SHA='56f1fca056efc933a39226fa767328a0082ebd42ec3c4d2e0193a37ac44abdee' }
    $treeHash = '4da28eaffcdee2a3dd8b43f046fa23bd96563aa68af4dcc03dd3b984924d683b'
} else {
    $modelBase = 'https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/7dabda4d13d513e3e842b20f0d435c732f172cbe/'
    $weights = @(@{ Name='qwen2.5-3b-instruct-q4_k_m.gguf'; Local='qwen.gguf'; Bytes=2104932768; SHA='626b4a6678b86442240e33df819e00132d3ba7dddfe1cdc4fbb18e0a9615c62d' })
    $engine = @{ Name='llama-b12613-bin-win-cpu-x64.zip'; Bytes=25009376; SHA='4c4ca218083b090393f517b598e7c86fc61e62f4d15f8748d6fedf24f809f429' }
    $treeHash = '132ba2221949077818855bfe42c4bd4b79a8092eef6bd961af1c76cdef3f0080'
}
$engine.Local = 'llama.zip'
foreach ($part in $weights) { if (!$part.Local) { $part.Local = $part.Name } }

function Get-Digest($Path) {
    $sha = [Security.Cryptography.SHA256]::Create()
    $stream = [IO.File]::OpenRead($Path)
    try { [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','').ToLowerInvariant() }
    finally { $stream.Dispose(); $sha.Dispose() }
}

function Assert-File($Path, $Spec) {
    if (![IO.File]::Exists($Path) -or ([IO.FileInfo]$Path).Length -ne $Spec.Bytes -or
        (Get-Digest $Path) -ne $Spec.SHA) {
        throw "Missing or incorrect file: $Path"
    }
}

function Get-VerifiedFile($Base, $Spec, $Folder) {
    $target = Join-Path $Folder $Spec.Local
    Write-Host "Preparing $($Spec.Name)..."
    if ($CacheDir) {
        $source = Join-Path $CacheDir $Spec.Name
        if (![IO.File]::Exists($source)) { $source = Join-Path $CacheDir $Spec.Local }
        [IO.File]::Copy($source, $target)
    } else {
        $uri = [uri]($Base + $Spec.Name)
        for ($hop = 0; $hop -lt 10; $hop++) {
            if ($uri.Scheme -ne 'https' -or $uri.Host -notmatch '(^|\.)(github\.com|githubusercontent\.com|huggingface\.co|hf\.co)$') {
                throw "Unexpected download host or protocol: $($uri.Host)"
            }
            $req = [Net.HttpWebRequest]::Create($uri)
            $req.AllowAutoRedirect = $false
            $req.UserAgent = 'Pulse-Model-Preparation'
            $res = $req.GetResponse()
            try {
                if ([int]$res.StatusCode -in 301,302,303,307,308) {
                    $uri = [uri]::new($uri, $res.Headers['Location'])
                    continue
                }
                if ([int]$res.StatusCode -ne 200) { throw "Download returned $($res.StatusCode)." }
                $out = [IO.File]::Open($target, [IO.FileMode]::CreateNew)
                try { $res.GetResponseStream().CopyTo($out) } finally { $out.Dispose() }
                break
            } finally { $res.Dispose() }
        }
    }
    Assert-File $target $Spec
}

# Digest of the sorted (file name, file SHA-256) list from the verified release ZIP.
function Assert-Runtime($Folder) {
    $names = [string[]]@(Get-ChildItem -LiteralPath $Folder -Force | Select-Object -ExpandProperty Name)
    [Array]::Sort($names, [StringComparer]::Ordinal)
    $list = [Text.StringBuilder]::new()
    foreach ($name in $names) {
        $digest = Get-Digest (Join-Path $Folder $name)
        [void]$list.Append("$name $digest" + [char]10)
    }
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $digest = [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::ASCII.GetBytes($list.ToString()))).Replace('-','') }
    finally { $sha.Dispose() }
    if ($digest -ne $treeHash) { throw "Unexpected runtime files: $Folder" }
}

if (Test-Path -LiteralPath $dest) {
    if ($Profile -eq '3B' -and (Test-Path -LiteralPath (Join-Path $dest 'qwen2.5-7b-instruct-q4_k_m-00001-of-00002.gguf'))) {
        throw "This directory contains 7B weights. Select a different ModelDir for 3B."
    }
    foreach ($part in $weights) { Assert-File (Join-Path $dest $part.Local) $part }
    Assert-Runtime (Join-Path $dest 'runtime')
    Write-Host "Verified existing Qwen $Profile in $dest"
    return
}

$parent = [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dest)).FullName
$stage = Join-Path $parent ('.pulse-qwen-' + [guid]::NewGuid())
[void](New-Item -ItemType Directory -Path $stage)
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Get-VerifiedFile $engineBase $engine $stage
    $zip = Join-Path $stage $engine.Local
    $runtime = Join-Path $stage 'runtime'
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::ExtractToDirectory($zip, $runtime)
    Assert-Runtime $runtime
    [IO.File]::Delete($zip)
    foreach ($part in $weights) { Get-VerifiedFile $modelBase $part $stage }
    [IO.Directory]::Move($stage, $dest)
    Write-Host "Ready: Qwen $Profile in $dest"
} finally {
    if ([IO.Directory]::Exists($stage) -and [IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($stage)) -eq $parent) {
        Remove-Item -LiteralPath $stage -Recurse -Force
    }
}
